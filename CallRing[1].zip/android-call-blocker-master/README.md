# android-call-blocker

I used to use an app from the Play Store to based on prefix but it stopped working with Android P (API level 28 now requires system permission MODIFY_PHONE_STATE to block calls), so I decided to build my own Android P-compliant call blocker app.
